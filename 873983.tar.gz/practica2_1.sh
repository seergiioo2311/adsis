#!/bin/bash
#873983, Isla Lasheras, Sergio, T, 1, A

echo -n "Introduzca el nombre del fichero: " 
read fichero

if ($(test -f "$fichero")); then
	echo -n "Los permisos del archivo $fichero son: "
	
	if ($(test -r "$fichero")); then 
		echo -n "r"
	else
		echo -n "-"
	fi

	if ($(test -w "$fichero")); then
		echo -n "w"
	else
		echo -n "-"
	fi

	if ($(test -x "$fichero")); then 
		echo "x"
	else
		echo "-"
	fi
else
	echo "$fichero no existe"
fi
