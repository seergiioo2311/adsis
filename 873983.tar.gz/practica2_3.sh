#!/bin/bash
#873983, Isla Lasheras, Sergio, T, 1, A

case "$#" in
	1)
		if ($(test -f "$1")); then 
			chmod ug+x "$1"
			stat -c %A "$1"
		else
			echo "$1 no existe"
		fi
		;;
	*)
		echo "Sintaxis: practica2_3.sh <nombre_archivo>"
		;;
esac	
