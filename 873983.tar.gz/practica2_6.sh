#!/bin/bash
#873983, Isla Lasheras, Sergio, T, 1, A

ndirectorios=$(ls -p "$HOME" | grep "bin[a-zA-Z0-9][a-zA-Z0-9][a-zA-Z0-9]/" | wc -l)

if ("$ndirectorios" -ne 0); then
	x=0
	for i in $(ls -p "$HOME" | grep "bin[a-zA-Z0-9][a-zA-Z0-9][a-zA-Z0-9]/")
	do
		if ("$(stat -c%Y $HOME/$i)" -gt $x); then
			dir="$HOME/$i"	
			dirbin=${dir:0:"#dir"-1}	
		fi
	done
else
	dirbin=$(mktemp -d "$HOME/binXXX")
	echo "Se ha creado el directorio $dirbin"
fi

contador=0

echo "Directorio destino de copia: $dirbin"
for i in *
do 
	if ($(test -x "$i" -a ! -d "$i")); then
		cp "$i" "$dirbin"
		echo "./$i ha sido copiado a $dirbin"
		contador=$((contador++))
	fi
done

if ("$contador" -ne 0); then
	echo "Se han copiado $contador archivos"
else
	echo "No se ha copiado ningun archivo"
fi
