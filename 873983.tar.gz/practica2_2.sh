#!/bin/bash
#873983, Isla Lasheras, Sergio, T, 1, A

for i in "$@" 
do
	if ($(test -f "$i")); then
		more "$i"
	else	
		echo "$i no es un fichero"
	fi	
done
