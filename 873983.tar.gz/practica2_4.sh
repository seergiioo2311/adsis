#!/bin/bash
#873983, Isla Lasheras, Sergio, T, 1, A

echo -n "Introduzca una tecla: "
read entrada

caracter=$(echo $entrada | cut -c 1)

case $caracter in 
	[[:alpha:]])
		echo "$caracter es una letra"
		;;
	[[:digit:]])
		echo "$caracter es un numero"
		;;
	*)
		echo "$caracter es un caracter especial"
		;;
esac
