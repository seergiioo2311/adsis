#!/bin/bash
#873983, Isla Lasheras, Sergio, T, 1, A

echo -n "Introduzca el nombre de un directorio: "
read directorio

if ($(test -d "$directorio")); then	
	numficheros=$(ls "$directorio" -p| grep -v / | wc -l)
	numdirectorios=$(ls "$directorio" -p| grep / | wc -l)
	echo "El numero de ficheros y directorios en $directorio es de $numficheros y $numdirectorios, respectivamente"
else
	echo "$directorio no es un directorio"
fi
